<?php
echo:'please insert this shortcode anywhere in yoour code '